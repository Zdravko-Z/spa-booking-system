package com.fundamentals.spa.controller;

import com.fundamentals.spa.exception.*;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(EmailAlreadyUsedException.class)
    public String handleEmailExists(EmailAlreadyUsedException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/already-exists";  // templates/error/not-found.html
    }

    @ExceptionHandler(EmailNotPresent.class)
    public String handleEmailNotFound(EmailNotPresent ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/not-found";
    }

    @ExceptionHandler(InvalidBookingStatusException.class)
    public String handleInvalidStatus(InvalidBookingStatusException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/invalid-booking-status";
    }

    @ExceptionHandler(SpaBookingNotFoundException.class)
    public String handleBookingNotFound(SpaBookingNotFoundException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/not-found";
    }

    @ExceptionHandler(SpaRoomNotFoundException.class)
    public String handleRoomNotFound(SpaRoomNotFoundException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/not-found";
    }

    @ExceptionHandler(SpaStaffNotFoundException.class)
    public String handleStaffNotFound(SpaStaffNotFoundException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/not-found";
    }

    @ExceptionHandler(SpaTreatmentNotFoundException.class)
    public String handleTreatmentNotFound(SpaTreatmentNotFoundException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/not-found";
    }

    @ExceptionHandler(SpaUserNotFound.class)
    public String handleUserNotFound(SpaUserNotFound ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/not-found";
    }

    @ExceptionHandler(UnauthorizedActionException.class)
    public String handleUnauthorizedAction(UnauthorizedActionException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/unauthorized-action";
    }

    @ExceptionHandler(UsernameOrPasswordMismatch.class)
    public String handleCredentialsMismatch(UsernameOrPasswordMismatch ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/credentials-mismatch";
    }

    @ExceptionHandler(SpaException.class)
    public String handleGeneral(SpaException ex, Model model) {
        model.addAttribute("error", ex.getMessage());
        return "error/general";
    }
}
