package com.fundamentals.spa.dto;

import lombok.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
public class SpaBookingForm {
    private LocalDate bookingDate;
    private LocalTime startTime;
    private List<UUID> treatmentIds;
    private UUID staffId;
    private String notes;
}
