package com.fundamentals.spa.dto;

import com.fundamentals.spa.entity.enums.BookingStatus;
import lombok.Builder;
import lombok.Getter;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

@Getter
@Builder
public class SpaBookingDto {
    private String confirmationCode;
    private LocalDate bookingDate;
    private LocalTime startTime;
    private LocalTime endTime;
    private int durationMinutes;
    private BigDecimal totalPrice;
    private BookingStatus status = BookingStatus.PENDING;
    private String notes;
    private GuestDto guestDto;
    private SpaRoomDto spaRoomDto;
    private SpaStaffDto spaStaffDto;
}
