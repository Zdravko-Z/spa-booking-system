package com.fundamentals.spa.dto;

import lombok.*;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Setter
public class LoginDto {
    private String username;
    private String password;
}
